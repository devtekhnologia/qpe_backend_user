export interface Data {
    name: string;
    school_id: string;
    status: number;
    created_by: string;
    created_at: string;
    user_id?: string
}